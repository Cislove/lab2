public class I extends null {

    float ff();

    void bb();
}
