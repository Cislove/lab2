public class J {

    private String k = "init";

    private long c = 4321;

    public int ae() {
        return 9;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public long ac() {
        return 333;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public void ab() {
        System.out.println("\n");
    }
}
