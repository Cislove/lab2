public class E extends null {

    int af();

    int cc();

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }
}
