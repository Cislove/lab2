public class I extends null {

    float ff();

    void bb();

    public int hh() {
        return new java.util.Random().nextInt();
    }
}
