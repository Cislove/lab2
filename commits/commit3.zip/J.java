public class J {

    private String k = "init";

    private long c = 4321;

    public int ae() {
        return 9;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public long ac() {
        return 333;
    }
}
