public class B implements I {

    private long k = 4321;

    private long f = 1234;

    public long ac() {
        return 111;
    }

    public void ab() {
        return;
    }

    public float ff() {
        return 3.14;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public byte oo() {
        return 3;
    }
}
