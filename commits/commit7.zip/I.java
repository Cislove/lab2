public interface I {

    float ff();

    void bb();
}
