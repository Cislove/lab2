public interface E {

    int af();

    int cc();
}
