public class I extends null {

    float ff();

    void bb();

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}
