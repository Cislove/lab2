public class J extends null {

    private String k = "init";

    private long c = 4321;

    public int ae() {
        return 9;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public long ac() {
        return 333;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public void ab() {
        System.out.println();
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public void bb() {
        System.out.println(42);
    }

    public float ff() {
        return 0;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }
}
