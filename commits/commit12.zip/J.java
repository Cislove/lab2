public class J extends null {

    private String k = "init";

    private long c = 4321;

    public int ae() {
        return 9;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public void ab() {
        System.out.println("\n");
    }

    public long ac() {
        return 333;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public void bb() {
        System.out.println(42);
    }

    public double ad() {
        return 9.11;
    }
}
